import re
import string


def printOverallFreq():
    new_list = []   # empty list for later

    text_file = open("ProduceList.txt", "r")        # open and read the text file then create a list of the words from the file
    content_file = text_file.read()
    content_list = content_file.split("\n")   
    text_file.close()

    for i in content_list:          # for loop that that copies file list to new_list without the duplicates
        if i not in new_list:
            new_list.append(i)
    for x in new_list:              # for loop that prints the items from new_list (no duplicates) and their frequency from the original file list (with duplicates)
        print(x, end=" ")
        print(content_list.count(x))

def printIndividualFreq(v):

    text_file = open("ProduceList.txt", "r")    # opens, reads, and creates list of file content
    content_file = text_file.read()
    content_list = content_file.split("\n")
    text_file.close()

    if v in content_list:               # checks if user input is in the list and then prints the number of times the item was sold
        print(v, end=" ")
        print("were purchased", end=" ")
        print(content_list.count(v), end=" ")
        print("time(s).")
    else:
        print("Item not found, please try again.")      # if user input isnt in list

    return 100;

def printHistogram():

    new_list = []   # empty list for later

    text_file = open("ProduceList.txt", "r")        # open and read the text file then create a list of the words from the file
    content_file = text_file.read()
    content_list = content_file.split("\n")   
    text_file.close()

    for i in content_list:          # for loop that that copies file list to new_list without the duplicates
        if i not in new_list:
            new_list.append(i)

    for x in new_list:              # for loop that prints the items from new_list (no duplicates) and their frequency in '*' from the original file list (with duplicates)
        print(x, end=" ")

        for n in range(0, content_list.count(x)):
            print("*", end="")

        print()
